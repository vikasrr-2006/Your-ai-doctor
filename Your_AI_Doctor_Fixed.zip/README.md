# Your AI Doctor

A medical symptom prediction system powered by machine learning that helps users identify potential diseases based on their symptoms.

## Features

- **Symptom-Based Prediction**: Select from 25 common symptoms to get disease predictions
- **Machine Learning Models**: Uses Decision Tree and Random Forest algorithms for accurate predictions
- **Disease Information**: Provides treatment, prevention, and consultation advice
- **Ayurvedic Remedies**: Includes traditional Ayurvedic prevention and remedies
- **Doctor Finder**: Find nearby doctors by specialization in Mandya district
- **Location-Based Search**: Detects user location to find the nearest doctors
- **Emergency Alerts**: Flags critical symptoms that require immediate attention
- **Responsive Design**: Works on desktop and mobile devices

## Tech Stack

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript
- **Machine Learning**: scikit-learn (Decision Tree, Random Forest)
- **Database**: JSON-based data storage
- **Proxy**: PHP proxy for XAMPP integration

## Data Files

The application uses structured JSON and CSV data files for symptom-disease mapping:

- **`data/symptom_disease_map.json`** - Primary mapping file containing disease predictions for all 25 symptoms across all 625 symptom combinations (25 × 25).
- **`data/symptom_disease_dataset.csv`** - CSV format reference of the same mapping for easy viewing and analysis.

### Symptom → Single Disease Mapping

Each of the 25 symptoms maps to a specific disease when selected alone:

| Symptom | Disease |
|---------|---------|
| Fever | Viral Fever |
| Cough | Common Cold |
| Headache | Tension Headache |
| Fatigue | Weakness / Tiredness |
| Sore Throat | Throat Infection |
| Runny Nose | Cold / Allergies |
| Chest Pain | Acidity / Gas |
| Shortness of Breath | Breathing Problem |
| Nausea | Stomach Upset |
| Vomiting | Food Poisoning |
| Diarrhea | Loose Motion |
| Abdominal Pain | Stomach Pain |
| Back Pain | Muscle Strain |
| Joint Pain | Body Pain |
| Muscle Pain | Body Ache |
| Dizziness | Low BP / Weakness |
| Rash | Skin Allergy |
| Itching | Allergy |
| Swelling | Inflammation |
| Blurred Vision | Eye Strain |
| Hearing Loss | Ear Blockage |
| Insomnia | Sleep Problem |
| Anxiety | Stress |
| Depression | Mental Stress |
| Wheezing | Asthma / Allergy |

## Project Structure

```
Your AI Doctor/
├── app.py                          # Flask application main file
├── create_models.py                # ML model training script
├── start_flask.bat                 # Windows batch file to start Flask
├── requirements.txt                # Python dependencies
├── index.html                      # Redirect page
├── index.php                       # XAMPP entry point with Flask check
├── proxy.php                       # PHP proxy for Flask requests
├── access.html                     # Access guide page
├── README.md                       # This file
├── XAMPP_ACCESS_GUIDE.md          # XAMPP setup guide
├── models/
│   ├── decision_tree.pkl           # Trained Decision Tree model
│   └── random_forest.pkl           # Trained Random Forest model
├── data/
│   ├── disease_solutions.json      # Disease information database
│   ├── diagnostic_testing_matrix.json  # Diagnostic test recommendations
│   ├── doctors_database.json       # Doctor directory
│   ├── symptom_disease_map.json    # Symptom-disease mapping (JSON)
│   └── symptom_disease_dataset.csv # Symptom-disease mapping (CSV)
├── services/
│   ├── __init__.py                 # Package init file
│   └── symptom_mapper.py           # Symptom-disease mapping logic
├── static/
│   ├── css/
│   │   └── style.css               # Main stylesheet
│   └── js/
│       ├── script.js               # Home page JavaScript
│       ├── consult.js              # Consult page JavaScript
│       └── main.js                 # Shared utilities
└── templates/
    ├── index.html                  # Home page template
    ├── consult.html                # Doctor consultation page
    └── about.html                  # About page
```

## Usage

### Symptom Prediction

1. Navigate to the home page
2. Select symptoms you are experiencing from the checkbox list
3. Click "Predict Disease"
4. View the prediction results including:
   - Predicted disease with confidence percentage
   - Alternative predictions
   - Treatment recommendations
   - Prevention tips
   - Ayurvedic remedies

### Finding Doctors

1. Click "Consult Doctors" in the navigation
2. Select a medical specialization
3. Optionally detect your location for distance-based sorting
4. View doctor details and click "View on Google Maps" for directions

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Home page with symptom selection |
| `/predict` | POST | Disease prediction from symptoms |
| `/api/diagnosis` | POST | Detailed diagnostic information |
| `/consult` | GET | Doctor consultation page |
| `/api/doctors` | GET | Get filtered doctor list |
| `/about` | GET | About page |

### Example: Predict API

```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"symptoms": ["Fever", "Cough", "Fatigue"]}'
```

## Configuration

The application runs on port 5000 by default. To change the port, edit `app.py`:

```python
if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Change port here
```

## Dependencies

- Flask >= 2.0.0
- NumPy >= 1.21.0
- scikit-learn >= 1.0.0
- geopy >= 2.0.0 (optional, for geocoding)

## Disclaimer

This application is for educational and informational purposes only. Always consult a qualified healthcare professional for medical advice, diagnosis, or treatment.

## License

This project is provided as-is for educational purposes.
