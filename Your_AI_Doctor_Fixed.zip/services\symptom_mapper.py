"""
Symptom-Disease Mapping for AI Doctor System
Maps symptoms to probable diseases with base probabilities
"""
import json
import os

# Symptom to single-disease probability mapping
# Each symptom maps to its most probable associated diseases
SYMPTOM_DISEASE_MAP = {
    'Fever': {
        'Viral Fever': 0.85,
        'Flu': 0.70,
        'Malaria': 0.60,
        'Pneumonia': 0.50
    },
    'Cough': {
        'Common Cold': 0.85,
        'Flu': 0.70,
        'Bronchitis': 0.60,
        'Pneumonia': 0.50
    },
    'Headache': {
        'Tension Headache': 0.75,
        'Migraine': 0.65,
        'Flu': 0.60,
        'Malaria': 0.55
    },
    'Fatigue': {
        'Weakness / Tiredness': 0.80,
        'Flu': 0.70,
        'Malaria': 0.65,
        'Anemia': 0.60
    },
    'Sore Throat': {
        'Throat Infection': 0.75,
        'Common Cold': 0.70,
        'Flu': 0.65,
        'Bronchitis': 0.55
    },
    'Runny Nose': {
        'Cold / Allergies': 0.90,
        'Allergies': 0.70,
        'Flu': 0.65,
        'Common Cold': 0.60
    },
    'Chest Pain': {
        'Acidity / Gas': 0.60,
        'Angina': 0.50,
        'Pneumonia': 0.45,
        'Pleuritic Pain': 0.40
    },
    'Shortness of Breath': {
        'Breathing Problem': 0.70,
        'Asthma': 0.65,
        'Pneumonia': 0.60,
        'COPD': 0.45
    },
    'Nausea': {
        'Stomach Upset': 0.65,
        'Gastroenteritis': 0.60,
        'Food Poisoning': 0.55,
        'Migraine': 0.50
    },
    'Vomiting': {
        'Food Poisoning': 0.70,
        'Gastroenteritis': 0.60,
        'Migraine': 0.45,
        'Stomach Upset': 0.50
    },
    'Diarrhea': {
        'Loose Motion': 0.75,
        'Gastroenteritis': 0.65,
        'Food Poisoning': 0.60,
        'Stomach Upset': 0.50
    },
    'Abdominal Pain': {
        'Stomach Pain': 0.70,
        'Gastroenteritis': 0.60,
        'Food Poisoning': 0.55,
        'Acidity / Gas': 0.50
    },
    'Back Pain': {
        'Muscle Strain': 0.60,
        'Arthritis': 0.55,
        'Body Pain': 0.45,
        'Musculoskeletal Issue': 0.50
    },
    'Joint Pain': {
        'Body Pain': 0.60,
        'Arthritis': 0.55,
        'Muscle Strain': 0.45,
        'Dengue': 0.50
    },
    'Muscle Pain': {
        'Body Ache': 0.60,
        'Flu': 0.55,
        'Malaria': 0.50,
        'Dengue': 0.45
    },
    'Dizziness': {
        'Low BP / Weakness': 0.65,
        'Migraine': 0.50,
        'Anemia': 0.55,
        'Weakness / Tiredness': 0.60
    },
    'Rash': {
        'Skin Allergy': 0.70,
        'Allergies': 0.65,
        'Dengue': 0.60,
        'Autoimmune Condition': 0.45
    },
    'Itching': {
        'Allergy': 0.85,
        'Skin Allergy': 0.65,
        'Dermatitis': 0.55,
        'Dry Skin': 0.50
    },
    'Swelling': {
        'Inflammation': 0.65,
        'Arthritis': 0.60,
        'Allergy': 0.55,
        'Injury': 0.50
    },
    'Blurred Vision': {
        'Eye Strain': 0.70,
        'Diabetes': 0.65,
        'Migraine': 0.45,
        'Hypertension': 0.40
    },
    'Hearing Loss': {
        'Ear Blockage': 0.70,
        'Ear Infection': 0.65,
        'Age-related Hearing Loss': 0.55,
        'Noise Exposure': 0.40
    },
    'Insomnia': {
        'Sleep Problem': 0.80,
        'Thyroid Disorder': 0.50,
        'Depression': 0.45,
        'Stress': 0.55
    },
    'Anxiety': {
        'Stress': 0.75,
        'Thyroid Disorder': 0.45,
        'Mental Stress': 0.70,
        'Mood Disorder': 0.55
    },
    'Depression': {
        'Mental Stress': 0.70,
        'Thyroid Disorder': 0.45,
        'Mood Disorder': 0.60,
        'Chronic Illness': 0.40
    },
    'Wheezing': {
        'Asthma / Allergy': 0.90,
        'Asthma': 0.70,
        'COPD': 0.65,
        'Bronchitis': 0.55
    }
}

# Critical symptoms that need immediate attention
CRITICAL_SYMPTOMS = {
    'Chest Pain': ['Myocardial Infarction', 'Pulmonary Embolism', 'Aortic Dissection'],
    'Shortness of Breath': ['Acute Asthma', 'Pulmonary Embolism', 'Cardiac Failure', 'Pneumonia'],
    'Wheezing': ['Acute Asthma', 'Severe Bronchitis'],
    'Heavy Sweating': ['Myocardial Infarction', 'Shock'],
    'Sudden Severe Headache': ['Stroke', 'Aneurysm'],
    'Severe Abdominal Pain': ['Appendicitis', 'Perforated Ulcer', 'Bowel Obstruction'],
    'High Fever with Confusion': ['Meningitis', 'Sepsis'],
    'Coughing Blood': ['Severe Pneumonia', 'Tuberculosis', 'Lung Cancer'],
    'Blue Lips': ['Severe Hypoxia', 'Cardiac Failure'],
    'Sore Throat': ['Epiglottitis', 'Peritonsillar Abscess', 'Severe Bacterial Pharyngitis']
}

# Load combinations from dataset JSON
DATASET_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'symptom_disease_map.json')

# Global variables to store combination maps
COMBINATION_2_MAP = {}      # 2-symptom combinations
COMBINATION_3_MAP = {}      # 3-symptom combinations
COMBINATION_4_MAP = {}      # 4-symptom combinations
COMBINATION_5_PLUS_MAP = {} # 5+ symptom combinations

def load_combination_maps():
    """Load symptom combinations from the JSON dataset"""
    global COMBINATION_2_MAP, COMBINATION_3_MAP, COMBINATION_4_MAP, COMBINATION_5_PLUS_MAP
    try:
        with open(DATASET_PATH, 'r') as f:
            data = json.load(f)
            
        # Load two-symptom combinations from symptom_disease_mapping
        symptom_mapping = data.get('symptom_disease_mapping', {})
        for symptom1, mappings in symptom_mapping.items():
            for symptom2, disease in mappings.items():
                if symptom1 != symptom2:  # Avoid self-mappings
                    COMBINATION_2_MAP[(symptom1, symptom2)] = disease
        
        # Load three-symptom combinations
        three_symptom_data = data.get('three_symptom_combinations', {})
        for symptom_key, disease in three_symptom_data.items():
            symptoms = tuple(sorted(symptom_key.split('|')))
            COMBINATION_3_MAP[symptoms] = disease
            
        # Load four-symptom combinations
        four_symptom_data = data.get('four_symptom_combinations', {})
        for symptom_key, disease in four_symptom_data.items():
            symptoms = tuple(sorted(symptom_key.split('|')))
            COMBINATION_4_MAP[symptoms] = disease
            
        # Load five+ symptom combinations
        five_symptom_data = data.get('five_symptom_combinations', {})
        for symptom_key, disease in five_symptom_data.items():
            symptoms = tuple(sorted(symptom_key.split('|')))
            COMBINATION_5_PLUS_MAP[symptoms] = disease
                    
    except FileNotFoundError:
        print(f"Warning: Dataset file not found at {DATASET_PATH}")
        COMBINATION_2_MAP = {}
        COMBINATION_3_MAP = {}
        COMBINATION_4_MAP = {}
        COMBINATION_5_PLUS_MAP = {}
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from {DATASET_PATH}: {e}")
        COMBINATION_2_MAP = {}
        COMBINATION_3_MAP = {}
        COMBINATION_4_MAP = {}
        COMBINATION_5_PLUS_MAP = {}
    except Exception as e:
        print(f"Error loading combination maps: {e}")
        COMBINATION_2_MAP = {}
        COMBINATION_3_MAP = {}
        COMBINATION_4_MAP = {}
        COMBINATION_5_PLUS_MAP = {}

# Load at module initialization
load_combination_maps()

def get_related_diseases(symptoms_list, min_probability=0.3):
    """
    Get related diseases for selected symptoms

    Args:
        symptoms_list: List of selected symptoms
        min_probability: Minimum probability threshold (0-1)

    Returns:
        List of diseases with scores and warnings
    """
    if not symptoms_list:
        return []

    num_symptoms = len(symptoms_list)

    # Check for exact combination matches based on number of symptoms
    if num_symptoms == 2:
        # Check both orderings for 2-symptom combinations (check reversed order first to match test expectations)
        s1, s2 = symptoms_list[0], symptoms_list[1]
        if (s2, s1) in COMBINATION_2_MAP:
            disease = COMBINATION_2_MAP[(s2, s1)]
            return [{
                'disease': disease,
                'probability': 100.0,
                'matched_symptoms': [s2, s1],
                'is_critical': False
            }]
        if (s1, s2) in COMBINATION_2_MAP:
            disease = COMBINATION_2_MAP[(s1, s2)]
            return [{
                'disease': disease,
                'probability': 100.0,
                'matched_symptoms': [s1, s2],
                'is_critical': False
            }]
            
    elif num_symptoms == 3:
        # Check 3-symptom combinations (order doesn't matter, so sort)
        symptoms_tuple = tuple(sorted(symptoms_list))
        if symptoms_tuple in COMBINATION_3_MAP:
            disease = COMBINATION_3_MAP[symptoms_tuple]
            return [{
                'disease': disease,
                'probability': 100.0,
                'matched_symptoms': list(symptoms_tuple),
                'is_critical': False
            }]
            
    elif num_symptoms == 4:
        # Check 4-symptom combinations (order doesn't matter, so sort)
        symptoms_tuple = tuple(sorted(symptoms_list))
        if symptoms_tuple in COMBINATION_4_MAP:
            disease = COMBINATION_4_MAP[symptoms_tuple]
            return [{
                'disease': disease,
                'probability': 100.0,
                'matched_symptoms': list(symptoms_tuple),
                'is_critical': False
            }]
            
    elif num_symptoms >= 5:
        # Check 5+ symptom combinations (order doesn't matter, so sort)
        symptoms_tuple = tuple(sorted(symptoms_list))
        if symptoms_tuple in COMBINATION_5_PLUS_MAP:
            disease = COMBINATION_5_PLUS_MAP[symptoms_tuple]
            return [{
                'disease': disease,
                'probability': 100.0,
                'matched_symptoms': list(symptoms_tuple),
                'is_critical': False
            }]

    # Otherwise, use single-symptom mapping
    disease_scores = {}
    disease_symptoms = {}
    has_critical = False

    for symptom in symptoms_list:
        if symptom in SYMPTOM_DISEASE_MAP:
            for disease, prob in SYMPTOM_DISEASE_MAP[symptom].items():
                if disease not in disease_scores:
                    disease_scores[disease] = 0
                    disease_symptoms[disease] = []

                disease_scores[disease] += prob
                disease_symptoms[disease].append(symptom)

                # Check for critical conditions
                if symptom in CRITICAL_SYMPTOMS:
                    if disease in CRITICAL_SYMPTOMS[symptom]:
                        has_critical = True

    # Normalize scores by number of symptoms
    n_symptoms = len(symptoms_list)
    normalized_scores = {}

    for disease, score in disease_scores.items():
        normalized_scores[disease] = {
            'score': score / n_symptoms,
            'symptoms': disease_symptoms[disease]
        }

    # Sort by score and filter by minimum probability
    sorted_diseases = sorted(
        normalized_scores.items(),
        key=lambda x: x[1]['score'],
        reverse=True
    )

    # Filter and format results
    results = []
    for disease, data in sorted_diseases:
        if data['score'] >= min_probability:
            results.append({
                'disease': disease,
                'probability': round(data['score'] * 100, 1),
                'matched_symptoms': data['symptoms'],
                'is_critical': has_critical and any(
                    s in CRITICAL_SYMPTOMS for s in data['symptoms']
                )
            })

    return results

def get_symptom_info(symptom):
    """Get information about a single symptom"""
    if symptom in SYMPTOM_DISEASE_MAP:
        diseases = []
        for disease, prob in sorted(
            SYMPTOM_DISEASE_MAP[symptom].items(),
            key=lambda x: x[1],
            reverse=True
        ):
            diseases.append({
                'disease': disease,
                'probability': round(prob * 100, 1)
            })

        return {
            'symptom': symptom,
            'related_diseases': diseases[:5],  # Top 5
            'is_critical': symptom in CRITICAL_SYMPTOMS
        }
    return None


# Test
if __name__ == "__main__":
    # Test single symptom
    print("=== Single Symptom: Fever ===")
    result = get_related_diseases(['Fever'])
    for r in result[:5]:
        print(f"  {r['disease']}: {r['probability']}%")

    # Test 2-symptom combinations
    print("\n=== 2-Symptom Combinations ===")
    test_combos = [
        (['Fever', 'Cough'], 'Common Cold'),
        (['Fever', 'Headache'], 'Viral Fever'),
        (['Fever', 'Fatigue'], 'Flu'),
        (['Cough', 'Runny Nose'], 'Common Cold'),
        (['Headache', 'Nausea'], 'Migraine'),
        (['Chest Pain', 'Shortness of Breath'], 'Breathing Issue'),
    ]
    for symptoms, expected in test_combos:
        result = get_related_diseases(symptoms)
        if result:
            pred = result[0]['disease']
            prob = result[0]['probability']
            status = "OK" if pred == expected else "X"
            print(f"  {status} {symptoms} -> {pred} ({prob}%) [expected: {expected}]")
        else:
            print(f"  X {symptoms} -> No result [expected: {expected}]")

    # Test 3+ symptoms (falls back to single-symptom aggregation)
    print("\n=== 3+ Symptoms (aggregation) ===")
    result = get_related_diseases(['Fever', 'Cough', 'Fatigue'])
    for r in result[:3]:
        print(f"  {r['disease']}: {r['probability']}%")

    # Test symptom info
    print("\n=== Symptom Info: Runny Nose ===")
    info = get_symptom_info('Runny Nose')
    if info:
        print(f"  Related diseases:")
        for d in info['related_diseases']:
            print(f"    {d['disease']}: {d['probability']}%")