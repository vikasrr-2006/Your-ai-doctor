// ================================================
// Your AI Doctor - Consult Page Scripts
// ================================================

// State (top level for accessibility)
let userLocation = null;
let currentSpecialization = '';

// DOM Elements (top level for accessibility)
let specializationSelect;
let detectLocationBtn;
let locationStatus;
let doctorsList;
let loadingDoctors;
let noDoctors;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize DOM Elements
    specializationSelect = document.getElementById('specialization');
    detectLocationBtn = document.getElementById('detectLocation');
    locationStatus = document.getElementById('locationStatus');
    doctorsList = document.getElementById('doctorsList');
    loadingDoctors = document.getElementById('loadingDoctors');
    noDoctors = document.getElementById('noDoctors');

    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });
    }

    // Specialization change handler
    if (specializationSelect) {
        specializationSelect.addEventListener('change', function() {
            currentSpecialization = this.value;
            loadDoctors();
        });
    }

    // Detect location button handler
    if (detectLocationBtn) {
        detectLocationBtn.addEventListener('click', detectUserLocation);
    }

    // Load doctors on page load
    loadDoctors();
});

// Function to detect user location
function detectUserLocation() {
    if (!navigator.geolocation) {
        locationStatus.textContent = 'Geolocation not supported';
        locationStatus.className = 'location-status error';
        return;
    }

    locationStatus.textContent = 'Detecting location...';
    locationStatus.className = 'location-status';
    detectLocationBtn.disabled = true;

    navigator.geolocation.getCurrentPosition(
        function(position) {
            userLocation = {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
            };
            locationStatus.textContent = 'Location detected!';
            locationStatus.className = 'location-status success';
            detectLocationBtn.disabled = false;
            
            // Reload doctors with location
            loadDoctors();
        },
        function(error) {
            let errorMessage = 'Unable to detect location';
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage = 'Location permission denied';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage = 'Location unavailable';
                    break;
                case error.TIMEOUT:
                    errorMessage = 'Location request timeout';
                    break;
            }
            locationStatus.textContent = errorMessage;
            locationStatus.className = 'location-status error';
            detectLocationBtn.disabled = false;
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

// Function to load doctors
async function loadDoctors() {
    showLoading();

    try {
        let url = 'api/doctors';
        const params = new URLSearchParams();

        if (currentSpecialization) {
            params.append('specialization', currentSpecialization);
        }

        if (userLocation) {
            params.append('latitude', userLocation.latitude);
            params.append('longitude', userLocation.longitude);
        }

        if (params.toString()) {
            url += '?' + params.toString();
        }

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error('Failed to fetch doctors');
        }

        const doctors = await response.json();
        displayDoctors(doctors);

    } catch (error) {
        console.error('Error loading doctors:', error);
        showError();
    }
}

// Function to display doctors
function displayDoctors(doctors) {
    hideAll();

    if (doctors.length === 0) {
        noDoctors.classList.remove('hidden');
        return;
    }

    doctorsList.innerHTML = '';

    doctors.forEach((doctor, index) => {
        const card = createDoctorCard(doctor, index);
        doctorsList.appendChild(card);
    });

    doctorsList.classList.remove('hidden');
}

// Function to create doctor card
function createDoctorCard(doctor, index) {
    const card = document.createElement('div');
    card.className = 'doctor-card';
    
    // Get initials for avatar
    const initials = doctor.name
        .replace('Dr.', '')
        .trim()
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase();

    // Generate map link with address for better accuracy
    const mapLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(doctor.hospital + ' ' + doctor.address)}`;

    card.innerHTML = `
        <div class="doctor-header">
            <div class="doctor-avatar">${initials}</div>
            <div class="doctor-info">
                <h3>${doctor.name}</h3>
                <span class="specialization">${doctor.specialization}</span>
            </div>
        </div>
        <div class="doctor-details">
            <div class="doctor-detail">
                <i class="fas fa-hospital"></i>
                <span>${doctor.hospital}</span>
            </div>
            <div class="doctor-detail">
                <i class="fas fa-map-marker-alt"></i>
                <span>${doctor.address}</span>
            </div>
            <div class="doctor-detail">
                <i class="fas fa-phone"></i>
                <span>${doctor.phone}</span>
            </div>
        </div>
        <div class="rating">
            ${generateStars(doctor.rating)}
            <span>${doctor.rating}</span>
        </div>
        ${doctor.distance ? `<div class="distance-tag">
            <i class="fas fa-location-arrow"></i>
            ${doctor.distance} km
        </div>` : ''}
        <div class="doctor-actions">
            <a href="${mapLink}" target="_blank" class="btn-map">
                <i class="fas fa-map"></i>
                View on Google Maps
            </a>
        </div>
    `;

    return card;
}

// Function to generate star rating
function generateStars(rating) {
    let stars = '';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }

    if (hasHalfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }

    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }

    return stars;
}

// Function to show loading
function showLoading() {
    hideAll();
    loadingDoctors.classList.remove('hidden');
}

// Function to show error
function showError() {
    hideAll();
    noDoctors.querySelector('h3').textContent = 'Error Loading Doctors';
    noDoctors.querySelector('p').textContent = 'Please try again later';
    noDoctors.classList.remove('hidden');
}

// Function to hide all
function hideAll() {
    loadingDoctors.classList.add('hidden');
    doctorsList.classList.add('hidden');
    noDoctors.classList.add('hidden');
    
    // Reset no doctors message
    noDoctors.querySelector('h3').textContent = 'No Doctors Found';
    noDoctors.querySelector('p').textContent = 'Try selecting a different specialization';
}

// Handle browser back/forward navigation
window.addEventListener('popstate', function() {
    loadDoctors();
});

// Handle visibility change (when user returns to the page)
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        loadDoctors();
    }
});
